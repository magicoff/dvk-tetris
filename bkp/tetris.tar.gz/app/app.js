/**
 * Tetris Game Engine
 * Полностью переписанный движок с нуля
 */

// === Константы ===
const COLS = 10;
const ROWS = 20;
const BLOCK_SIZE = 30;

// === Фигуры (тетромино) ===
const TETROMINOS = {
    I: { shape: [[0,0,0,0], [1,1,1,1], [0,0,0,0], [0,0,0,0]], color: 'cyan' },
    J: { shape: [[1,0,0], [1,1,1], [0,0,0]], color: 'blue' },
    L: { shape: [[0,0,1], [1,1,1], [0,0,0]], color: 'orange' },
    O: { shape: [[1,1], [1,1]], color: 'yellow' },
    S: { shape: [[0,1,1], [1,1,0], [0,0,0]], color: 'lime' },
    T: { shape: [[0,1,0], [1,1,1], [0,0,0]], color: 'purple' },
    Z: { shape: [[1,1,0], [0,1,1], [0,0,0]], color: 'red' }
};

const TETROMINO_KEYS = Object.keys(TETROMINOS);

// === Состояние игры ===
const state = {
    board: null,
    currentPiece: null,
    nextPiece: null,
    score: 0,
    highScore: parseInt(localStorage.getItem('tetrisHighScore') || '0', 10),
    level: 1,
    lines: 0,
    isPlaying: false,
    isPaused: false,
    isGameOver: false,
    dropInterval: null,
    dropSpeed: 1000
};

// === DOM элементы ===
let gridElement = null;
let scoreElement = null;
let levelElement = null;
let highScoreElement = null;
let nextShapeElement = null;

// === Инициализация ===
document.addEventListener('DOMContentLoaded', init);

function init() {
    // Получаем DOM элементы
    gridElement = document.getElementById('game-grid');
    scoreElement = document.getElementById('score-container');
    nextShapeElement = document.getElementById('next-shape-container');
    
    // Создаём элементы для уровня и рекорда
    createInfoElements();
    
    // Создаём игровое поле
    createGrid();
    
    // Настраиваем управление
    document.addEventListener('keydown', handleInput);
    
    // Запускаем игру
    resetGame();
    startGame();
}

function createInfoElements() {
    // Уровень
    levelElement = document.createElement('div');
    levelElement.id = 'level-container';
    levelElement.style.cssText = 'margin-bottom: 10px; font-size: 22px; color: #00ffff; text-shadow: 0 0 5px #00ffff, 0 0 10px #00ffff; letter-spacing: 2px;';
    scoreElement.parentNode.insertBefore(levelElement, scoreElement.nextSibling);
    
    // Рекорд
    highScoreElement = document.createElement('div');
    highScoreElement.id = 'highscore-container';
    highScoreElement.style.cssText = 'margin-bottom: 15px; font-size: 18px; color: #ff00ff; text-shadow: 0 0 5px #ff00ff, 0 0 10px #ff00ff; letter-spacing: 2px;';
    levelElement.parentNode.insertBefore(highScoreElement, levelElement.nextSibling);
    
    updateInfoDisplay();
}

function createGrid() {
    gridElement.innerHTML = '';
    for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {
            const cell = document.createElement('div');
            cell.className = 'cell empty';
            cell.dataset.row = row;
            cell.dataset.col = col;
            gridElement.appendChild(cell);
        }
    }
}

// === Создание доски ===
function createBoard() {
    return Array.from({ length: ROWS }, () => Array(COLS).fill(null));
}

// === Генератор случайных фигур (мешок) ===
let bag = [];

function getNextTetromino() {
    if (bag.length === 0) {
        bag = [...TETROMINO_KEYS];
        // Перемешиваем (алгоритм Фишера-Йетса)
        for (let i = bag.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [bag[i], bag[j]] = [bag[j], bag[i]];
        }
    }
    const key = bag.pop();
    return {
        shape: TETROMINOS[key].shape.map(row => [...row]),
        color: TETROMINOS[key].color,
        row: 0,
        col: Math.floor(COLS / 2) - Math.floor(TETROMINOS[key].shape[0].length / 2)
    };
}

// === Игровой цикл ===
function startGame() {
    state.isPlaying = true;
    state.isPaused = false;
    state.isGameOver = false;
    state.dropSpeed = 1000;
    
    state.nextPiece = getNextTetromino();
    spawnPiece();
    
    startDropLoop();
}

function startDropLoop() {
    if (state.dropInterval) {
        clearInterval(state.dropInterval);
    }
    state.dropInterval = setInterval(() => {
        if (state.isPlaying && !state.isPaused && !state.isGameOver) {
            drop();
        }
    }, state.dropSpeed);
}

function stopDropLoop() {
    if (state.dropInterval) {
        clearInterval(state.dropInterval);
        state.dropInterval = null;
    }
}

// === Спавн фигуры ===
function spawnPiece() {
    state.currentPiece = state.nextPiece;
    state.nextPiece = getNextTetromino();
    
    // Центрируем фигуру
    state.currentPiece.col = Math.floor(COLS / 2) - Math.floor(getPieceWidth(state.currentPiece.shape) / 2);
    state.currentPiece.row = 0;
    
    // Проверяем на проигрыш
    if (checkCollision(state.currentPiece.shape, state.currentPiece.row, state.currentPiece.col)) {
        gameOver();
        return;
    }
    
    render();
    drawNextPiece();
}

function getPieceWidth(shape) {
    return shape[0].length;
}

// === Проверка столкновений ===
function checkCollision(shape, offsetRow, offsetCol) {
    for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
            if (shape[row][col] === 1) {
                const newRow = offsetRow + row;
                const newCol = offsetCol + col;
                
                // Выход за границы
                if (newRow < 0 || newRow >= ROWS || newCol < 0 || newCol >= COLS) {
                    return true;
                }
                
                // Столкновение с застывшими фигурами
                if (state.board[newRow][newCol] !== null) {
                    return true;
                }
            }
        }
    }
    return false;
}

// === Движение ===
function drop() {
    if (!state.currentPiece || state.isPaused || state.isGameOver) return;
    
    const newRow = state.currentPiece.row + 1;
    
    if (checkCollision(state.currentPiece.shape, newRow, state.currentPiece.col)) {
        lockPiece();
        clearLines();
        spawnPiece();
    } else {
        state.currentPiece.row = newRow;
        render();
    }
}

function moveLeft() {
    if (!state.currentPiece || state.isPaused || state.isGameOver) return;
    
    const newCol = state.currentPiece.col - 1;
    if (!checkCollision(state.currentPiece.shape, state.currentPiece.row, newCol)) {
        state.currentPiece.col = newCol;
        render();
    }
}

function moveRight() {
    if (!state.currentPiece || state.isPaused || state.isGameOver) return;
    
    const newCol = state.currentPiece.col + 1;
    if (!checkCollision(state.currentPiece.shape, state.currentPiece.row, newCol)) {
        state.currentPiece.col = newCol;
        render();
    }
}

function rotate() {
    if (!state.currentPiece || state.isPaused || state.isGameOver) return;
    
    const originalShape = state.currentPiece.shape;
    const rotated = rotateShape(originalShape);
    
    // Пробуем повернуть
    if (!checkCollision(rotated, state.currentPiece.row, state.currentPiece.col)) {
        state.currentPiece.shape = rotated;
        render();
        return;
    }
    
    // Wall kick - пробуем сдвинуть влево/вправо
    const kicks = [-1, 1, -2, 2];
    for (const kick of kicks) {
        if (!checkCollision(rotated, state.currentPiece.row, state.currentPiece.col + kick)) {
            state.currentPiece.shape = rotated;
            state.currentPiece.col += kick;
            render();
            return;
        }
    }
}

function rotateShape(shape) {
    const rows = shape.length;
    const cols = shape[0].length;
    const rotated = Array.from({ length: cols }, () => Array(rows).fill(0));
    
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            rotated[col][rows - 1 - row] = shape[row][col];
        }
    }
    
    return rotated;
}

function hardDrop() {
    if (!state.currentPiece || state.isPaused || state.isGameOver) return;
    
    let dropDistance = 0;
    while (!checkCollision(state.currentPiece.shape, state.currentPiece.row + 1, state.currentPiece.col)) {
        state.currentPiece.row++;
        dropDistance++;
    }
    
    state.score += dropDistance * 2;
    updateInfoDisplay();
    
    lockPiece();
    clearLines();
    spawnPiece();
}

function softDrop() {
    if (!state.currentPiece || state.isPaused || state.isGameOver) return;
    
    if (!checkCollision(state.currentPiece.shape, state.currentPiece.row + 1, state.currentPiece.col)) {
        state.currentPiece.row++;
        state.score += 1;
        updateInfoDisplay();
        render();
    }
}

// === Фиксация фигуры ===
function lockPiece() {
    const { shape, row, col, color } = state.currentPiece;
    
    for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c] === 1) {
                const boardRow = row + r;
                const boardCol = col + c;
                if (boardRow >= 0 && boardRow < ROWS && boardCol >= 0 && boardCol < COLS) {
                    state.board[boardRow][boardCol] = color;
                }
            }
        }
    }
}

// === Очистка линий ===
function clearLines() {
    let linesCleared = 0;
    
    for (let row = ROWS - 1; row >= 0; row--) {
        if (state.board[row].every(cell => cell !== null)) {
            state.board.splice(row, 1);
            state.board.unshift(Array(COLS).fill(null));
            linesCleared++;
            row++; // Проверяем ту же строку снова
        }
    }
    
    if (linesCleared > 0) {
        // Очки за линии
        const points = [0, 100, 300, 500, 800];
        state.score += points[linesCleared] * state.level;
        state.lines += linesCleared;
        
        // Повышение уровня каждые 10 линий
        const newLevel = Math.floor(state.lines / 10) + 1;
        if (newLevel > state.level) {
            state.level = newLevel;
            increaseSpeed();
        }
        
        // Обновление рекорда
        if (state.score > state.highScore) {
            state.highScore = state.score;
            localStorage.setItem('tetrisHighScore', state.highScore.toString());
        }
        
        updateInfoDisplay();
    }
}

function increaseSpeed() {
    state.dropSpeed = Math.max(100, 1000 - (state.level - 1) * 100);
    startDropLoop();
}

// === Рендеринг ===
function render() {
    // Очищаем все ячейки
    const cells = gridElement.querySelectorAll('.cell');
    cells.forEach(cell => {
        cell.className = 'cell empty';
        // Удаляем все цвета
        Object.values(TETROMINOS).forEach(t => {
            cell.classList.remove(t.color);
        });
    });
    
    // Рисуем застывшие фигуры
    for (let row = 0; row < ROWS; row++) {
        for (let col = 0; col < COLS; col++) {
            if (state.board[row][col] !== null) {
                const cell = getCell(row, col);
                cell.classList.remove('empty');
                cell.classList.add('occupied', state.board[row][col]);
            }
        }
    }
    
    // Рисуем текущую фигуру
    if (state.currentPiece) {
        const { shape, row, col, color } = state.currentPiece;
        for (let r = 0; r < shape.length; r++) {
            for (let c = 0; c < shape[r].length; c++) {
                if (shape[r][c] === 1) {
                    const cell = getCell(row + r, col + c);
                    if (cell) {
                        cell.classList.remove('empty');
                        cell.classList.add('occupied', color);
                    }
                }
            }
        }
    }
}

function getCell(row, col) {
    return gridElement.querySelector(`[data-row="${row}"][data-col="${col}"]`);
}

function drawNextPiece() {
    if (!state.nextPiece) return;
    
    nextShapeElement.innerHTML = '<div>NEXT:</div>';
    
    const shape = state.nextPiece.shape;
    const color = state.nextPiece.color;
    
    // Находим реальные размеры фигуры (без пустых строк/столбцов)
    let minRow = shape.length, maxRow = 0, minCol = shape[0].length, maxCol = 0;
    for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c] === 1) {
                minRow = Math.min(minRow, r);
                maxRow = Math.max(maxRow, r);
                minCol = Math.min(minCol, c);
                maxCol = Math.max(maxCol, c);
            }
        }
    }
    
    const previewDiv = document.createElement('div');
    previewDiv.style.display = 'inline-block';
    previewDiv.style.textAlign = 'center';
    previewDiv.style.marginTop = '5px';
    
    for (let r = minRow; r <= maxRow; r++) {
        const rowDiv = document.createElement('div');
        rowDiv.style.lineHeight = '0';
        
        for (let c = minCol; c <= maxCol; c++) {
            const cell = document.createElement('div');
            cell.style.display = 'inline-block';
            cell.style.width = '15px';
            cell.style.height = '15px';
            cell.style.margin = '1px';
            cell.style.border = '1px solid #555';
            cell.style.boxSizing = 'border-box';
            
            if (shape[r][c] === 1) {
                cell.style.backgroundColor = color;
            } else {
                cell.style.backgroundColor = 'transparent';
            }
            
            rowDiv.appendChild(cell);
        }
        previewDiv.appendChild(rowDiv);
    }
    
    nextShapeElement.appendChild(previewDiv);
}

function updateInfoDisplay() {
    scoreElement.textContent = `SCORE: ${state.score}`;
    levelElement.textContent = `LEVEL: ${state.level}`;
    highScoreElement.textContent = `HI-SCORE: ${state.highScore}`;
}

// === Управление ===
function handleInput(event) {
    // Если игра не идёт - любой клик запускает рестарт
    if (state.isGameOver) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            resetGame();
            startGame();
        }
        return;
    }
    
    switch (event.key) {
        case 'ArrowLeft':
            event.preventDefault();
            moveLeft();
            break;
        case 'ArrowRight':
            event.preventDefault();
            moveRight();
            break;
        case 'ArrowDown':
            event.preventDefault();
            softDrop();
            break;
        case 'ArrowUp':
            event.preventDefault();
            rotate();
            break;
        case ' ':
            event.preventDefault();
            hardDrop();
            break;
        case 'p':
        case 'P':
        case 'Escape':
            event.preventDefault();
            togglePause();
            break;
    }
}

function togglePause() {
    state.isPaused = !state.isPaused;
    
    if (state.isPaused) {
        showOverlay('PAUSED', 'Press P or ESC to RESUME');
    } else {
        hideOverlay();
    }
}

function showOverlay(title, subtitle) {
    hideOverlay();
    
    const overlay = document.createElement('div');
    overlay.id = 'game-overlay';
    overlay.style.cssText = `
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.85);
        color: white;
        padding: 30px 40px;
        border-radius: 10px;
        text-align: center;
        z-index: 100;
        font-family: Arial, sans-serif;
    `;
    
    overlay.innerHTML = `
        <div style="font-size: 32px; font-weight: bold; margin-bottom: 10px;">${title}</div>
        <div style="font-size: 14px; color: #ccc;">${subtitle}</div>
    `;
    
    document.querySelector('.game-container').appendChild(overlay);
}

function hideOverlay() {
    const overlay = document.getElementById('game-overlay');
    if (overlay) {
        overlay.remove();
    }
}

// === Game Over ===
function gameOver() {
    state.isGameOver = true;
    state.isPlaying = false;
    stopDropLoop();
    
    showOverlay(
        'GAME OVER',
        `FINAL SCORE: ${state.score}<br>Press ENTER or SPACE to restart`
    );
}

function resetGame() {
    state.board = createBoard();
    state.score = 0;
    state.level = 1;
    state.lines = 0;
    state.dropSpeed = 1000;
    state.isGameOver = false;
    state.isPaused = false;
    state.currentPiece = null;
    state.nextPiece = null;
    bag = [];
    
    updateInfoDisplay();
    render();
    hideOverlay();
}
