# Tetris Web Game

## Project Overview

A browser-based **Tetris** game implemented using vanilla JavaScript, HTML, and CSS. This is a lightweight, client-side game with no external dependencies or build tools required.

### Technologies
- **HTML5** — Game structure and markup
- **CSS3** — Styling with Flexbox and CSS Grid
- **Vanilla JavaScript (ES6+)** — Game logic, no frameworks or libraries

### Architecture

```
test/
├── index.html      # Main HTML page, game container
├── style.css       # Game styling and layout
├── app/
│   └── app.js      # Core game logic
└── QWEN.md         # Project documentation
```

### Game Features
- Classic Tetris gameplay with 7 standard tetromino shapes (I, J, L, O, S, T, Z)
- Score tracking (+10 points per cleared line)
- Next shape preview
- Collision detection
- Line clearing mechanics
- Game over detection

### Controls
| Key | Action |
|-----|--------|
| ← | Move left |
| → | Move right |
| ↓ | Move down (soft drop) |
| ↑ | Rotate clockwise |

## Running the Game

No build process or server is strictly required. The game can be run directly in a browser:

```bash
# Option 1: Open directly in browser
open index.html

# Option 2: Use a simple HTTP server (recommended for proper script loading)
python3 -m http.server 8000
# Then navigate to: http://localhost:8000
```

## Development Notes

### Coding Style
- Uses ES6+ features: `const`, `let`, arrow functions, template literals
- Global scope for game functions (no module bundling)
- Direct DOM manipulation via `getElementById` and `querySelector`

### Game Logic Summary
1. **Grid System**: 10 columns × 20 rows
2. **Cell Size**: 30px × 30px with 1px gaps
3. **Tetrominoes**: Each shape has a defined matrix and color
4. **Game Loop**: Event-driven via keyboard input (no automatic game loop implemented)

### Known Limitations
- No automatic piece drop (gravity) — pieces only move on key press
- No pause/resume functionality
- No high score persistence
- All game state is in memory (resets on page reload)

## Future Enhancements (Suggestions)
- Add automatic gravity/game loop with `setInterval` or `requestAnimationFrame`
- Implement pause/resume functionality
- Add high score tracking with `localStorage`
- Add sound effects and background music
- Implement responsive design for mobile devices
- Add difficulty levels (speed adjustment)
